#include "client/libclient.h"
#include <iostream>
#include <chrono>
#include <string>
#include <cstdio>

using namespace std;

const size_t times = 10000;

void fs_mkdir(const string &path)
{
    IDX_Mkdir(path.c_str(), 0755);
}
void fs_mknod(const string &path)
{
    IDX_Mknod(path.c_str(), 0644);
}
void fs_readdir(const string &path)
{
    size_t num_entries;
    char** entries;
    IDX_Readdir(path.c_str(), &num_entries, &entries);

    // cout << num_entries << endl;
    // cout << entries[0] << endl;
    // cout << entries[1] << endl;
    // cout << entries[2] << endl;
}
void fs_chown_dir(const string &path, uid_t uid, gid_t gid)
{
    IDX_Chmod(path.c_str(), 0777);
}
void fs_rename_dir(const string &old_path, const string &new_path)
{
}
void fs_rmRF(const string &path)
{
}


// std::string strRand(const int len)
// {
//     std::string tmp_s;
//     static const char alphanum[] =
//         "0123456789"
//         "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
//         "abcdefghijklmnopqrstuvwxyz";
//     tmp_s.reserve(len);
//     for (int i = 0; i < len; ++i)
//         tmp_s += alphanum[rand() % (sizeof(alphanum) - 1)];
//     return tmp_s;
// }

int main()
{   
    if (IDX_Init(NULL) != 0)
    {
        cout << ("Error: connect to server failed!!!!");
        return -1;
    }
    /**
     * FUNCTIONALITY TEST
     */
    // fs_mkdir("/dir");
    // fs_mknod("/dir/f1");
    // fs_mknod("/dir/f2");
    // fs_mknod("/dir/f3");
    // fs_readdir("/dir");
    /**
     * Benchmark
     */
    string dir = "/dir";
    fs_mkdir(dir);
    for (int i = 0; i < 100; ++i)
    {
        fs_mknod( dir + string("/") + to_string(i) );
    }
    {
        printf("Readdir\t"); fflush(stdout);
        auto st = std::chrono::high_resolution_clock::now();
        for (size_t it = 0; it < times; it++)
        {
            fs_readdir("/dir");
        }
        auto ed = std::chrono::high_resolution_clock::now();
        long long latency = std::chrono::duration_cast<std::chrono::microseconds>(ed - st).count();
        double ave_latency = (double)latency / times;
        printf("%.6f\n", ave_latency); fflush(stdout);
    }



    // {
    //     printf("Chown Dir\t"); fflush(stdout);
    //     auto st = std::chrono::high_resolution_clock::now();
    //     for (size_t it = 0; it < times/2; it++)
    //     {
    //         fs_chown_dir("/dir", 2, 2);
    //         fs_chown_dir("/dir", 4, 4);
    //     }
    //     auto ed = std::chrono::high_resolution_clock::now();
    //     long long latency = std::chrono::duration_cast<std::chrono::microseconds>(ed - st).count();
    //     double ave_latency = (double)latency / times;
    //     printf("%.6f\n", ave_latency); fflush(stdout);
    // }
    // {
    //     printf("Rename Dir\t"); fflush(stdout);
    //     auto st = std::chrono::high_resolution_clock::now();
    //     for (size_t it = 0; it < times/2; it++)
    //     {
    //         fs_rename_dir(dir, dir + string("_renamed"));
    //         fs_rename_dir(dir + string("_renamed"), dir);
    //     }
    //     auto ed = std::chrono::high_resolution_clock::now();
    //     long long latency = std::chrono::duration_cast<std::chrono::microseconds>(ed - st).count();
    //     double ave_latency = (double)latency / times;
    //     printf("%.6f\n", ave_latency); fflush(stdout);
    // }
    // {
    //     printf("rmRf\t"); fflush(stdout);
    //     vector<long long> res;
    //     for (size_t i = 0; i < times; i++)
    //     {
    //         string dir = string("/dir_") + to_string(i);
    //         fs_mkdir(dir);
    //         for (int i = 0; i < 100; ++i)
    //         {
    //             fs_mknod( dir + string("/") + to_string(i) );
    //         }

    //         auto st = std::chrono::high_resolution_clock::now();
    //         fs_rmRF(dir);
    //         auto ed = std::chrono::high_resolution_clock::now();
    //         long long latency = std::chrono::duration_cast<std::chrono::microseconds>(ed - st).count(); 
    //         res.push_back(latency);
    //     }
        
    //     long long sum = 0;
    //     for (size_t i = 0; i < res.size(); ++i)
    //     {
    //         sum += res[i];
    //     }
    //     double ave_latency = (double)sum / times;
    //     printf("%.6f\n", ave_latency); fflush(stdout);
    // }

	IDX_Destroy();
    return 0;
}