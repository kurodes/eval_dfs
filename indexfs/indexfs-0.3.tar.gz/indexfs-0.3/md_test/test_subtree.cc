#include "client/libclient.h"

#include <iostream>
#include <string>
#include <vector>
#include <sys/time.h>

using namespace std;

string GeneCreatePath(int dep, int item)
{
    string ret = {"/"};
    for (int i = 0; i < dep; ++i)
    {
        ret += to_string(dep) + "." + to_string(item) + "/";
        IDX_Mkdir(ret.c_str(), 0755);
    }
    return ret;
}

string GenePath(int dep, int item)
{
    string ret = {"/"};
    for (int i = 0; i < dep; ++i)
    {
        ret += to_string(dep) + "." + to_string(item) + "/";
    }
    return ret;
}

void fs_mkdir(const string &path)
{
    IDX_Mkdir(path.c_str(), 0755);
}
void fs_mknod(const string &path)
{
    IDX_Mknod(path.c_str(), 0644);
}
void fs_readdir(const string &path)
{
    size_t num_entries;
    char **entries;
    IDX_Readdir(path.c_str(), &num_entries, &entries);

    // cout << num_entries << endl;
    // cout << entries[0] << endl;
    // cout << entries[1] << endl;
    // cout << entries[2] << endl;
}
void fs_chown_dir(const string &path, uid_t uid, gid_t gid)
{
    IDX_Chmod(path.c_str(), 0777);
}
void fs_rename_dir(const string &old_path, const string &new_path)
{
}
void fs_rmRF(const string &path)
{
}

uint64_t NowMicro()
{
    timeval tv;
    gettimeofday(&tv, NULL);
    return static_cast<uint64_t>(tv.tv_sec) * 1000 * 1000 + tv.tv_usec;
}

int main()
{
    if (IDX_Init(NULL) != 0)
    {
        cout << ("Error: connect to server failed!!!!");
        return -1;
    }

    const int depth = 10;
    const int test_times = 100;
    vector<string> dirpaths;

    // {
    //     for (int i = 0; i < test_times; ++i)
    //         dirpaths.push_back("/");
    //     for (int dep = 1; dep <= depth; ++dep)
    //     {
    //         for (int i = 0; i < test_times; ++i)
    //         {
    //             dirpaths.push_back(GeneCreatePath(dep, i));
    //         }
    //     }
    //     int count = 0;
    //     for (auto path : dirpaths)
    //     {
    //         cout << path << endl;
    //         IDX_Mknod((path + "file" + to_string(count)).c_str(), 0644);
    //         count += 1;
    //     }
    // }

    {
        for (int i = 0; i < test_times; ++i)
            dirpaths.push_back("/");
        for (int dep = 1; dep <= depth; ++dep)
        {
            for (int i = 0; i < test_times; ++i)
            {
                dirpaths.push_back(GenePath(dep, i));
            }
        }
        vector<uint64_t> Time;
        Time.push_back(NowMicro());
        int count = 0;
        for (auto path : dirpaths)
        {
            // cout << path << endl;
            struct stat buf;
            int ret = IDX_GetAttr((path + "file" + to_string(count)).c_str(), &buf);
            if (0 > ret)
            {
                cout << "error" << endl;
                return -1;
            }
            count += 1;
            if (count % test_times == 0)
            {
                Time.push_back(NowMicro());
                // cout << "time" << endl;
            }
        }
        for (int i = 0; i < depth + 1; ++i)
        {
            cout << (Time[i + 1] - Time[i]) / test_times << endl;
        }
    }

    IDX_Destroy();
    return 0;
}