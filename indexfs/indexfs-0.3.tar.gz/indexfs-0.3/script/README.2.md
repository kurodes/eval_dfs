# 编译 nonblocking server
```bash
autoreconf -ifv
./bootstrap.sh
export HADOOP_HOME=; echo $HADOOP_HOME; echo $LD_LIBRARY_PATH;
```

# 集群配置
etc/indexfs/

# 查看运行状态 cpu
pidstat -t -u -p `pidof indexfs_server` 2

# 更改数据路径
config.cc

# 集群启动
```bash
pscp -h /home/heifeng.lwh/nodes_all /home/heifeng.lwh/indexfs-0.3/etc/indexfs/server_list /home/heifeng.lwh/indexfs-0.3/etc/indexfs/server_list

pssh -h /home/heifeng.lwh/nodes_all -i 'ps -ef | grep "[m]etadata_server"' | grep SUCCESS | wc -l

./sbin/stop-all.sh
pssh -h /home/heifeng.lwh/nodes_all -i 'rm -rf /home/heifeng.lwh/tmpfs/indexfs'
./sbin/start-all.sh
```
# mdtest
```bash
mpirun --allow-run-as-root --mca btl ^openib -np 2 ./build/md_test/mdtest_nobk -z 3 -b 3 -I 30 -d /
mpirun --allow-run-as-root --mca btl ^openib -np 1 ./build/md_test/mdtest_nobk -z 3 -b 3 -I 30 -d /

./build/io_driver -task tree -dirs 1000 -files 1000

pssh -H '11.160.43.130 11.160.43.141' -i 'ps -ef | grep "[m]etadata_server"'

pscp -h /home/heifeng.lwh/nodes_all /home/heifeng.lwh/indexfs-0.3/etc/indexfs/server_list /home/heifeng.lwh/indexfs-0.3/etc/indexfs/server_list

./build/md_test/mdtest_nobk -z 9 -b 3 -I 4 -d /

mpirun --mca mpi_yield_when_idle 1 --mca btl ^openib --mca btl_tcp_if_include bond0 --mca plm_rsh_no_tree_spawn 1 \
-np 16 -hostfile /home/heifeng.lwh/indexfs-0.3/script/nodes_client_hostfile \
/home/heifeng.lwh/indexfs-0.3/build/md_test/mdtest_nobk -z 9 -b 3 -I 4 -d /
```

# 设置cache大小
export FS_DENT_CACHE_SIZE=4194304

4MB

metadata_client.cc:57
config.h:174