#!/usr/bin/env python2
from __future__ import print_function
import sys
import os
import time

def prRed(skk):
    print("\033[91m %s \033[00m" % skk)
    sys.stdout.flush()


def prGreen(skk):
    print("\033[92m %s \033[00m" % skk)
    sys.stdout.flush()


def prCyan(skk):
    print("\033[96m %s \033[00m" % skk)
    sys.stdout.flush()


def run_cmd(cmd):
    prGreen(cmd)
    os.system(cmd)
    return

def generate_pssh_hoststr(hostlist):
    hoststr = '\"'
    for i in hostlist:
        hoststr = hoststr + i + ' '
    hoststr = hoststr.strip(' ')
    hoststr = hoststr + '\"'
    return hoststr

def restart_indexfs():
    run_cmd('/home/heifeng.lwh/indexfs-0.3/sbin/stop-all.sh')
    run_cmd('pssh -h /home/heifeng.lwh/indexfs-0.3/script/nodes_server -i \'ps -ef | grep \"[m]etadata_server\"\'')
    run_cmd('pssh -h /home/heifeng.lwh/indexfs-0.3/script/nodes_server -i \'rm -rf /home/heifeng.lwh/tmpfs/indexfs\'')
    run_cmd('/home/heifeng.lwh/indexfs-0.3/sbin/start-all.sh')
    run_cmd('pssh -h /home/heifeng.lwh/indexfs-0.3/script/nodes_server -i \'ps -ef | grep \"[m]etadata_server\"\'')
    time.sleep(10)

mpiargs = str('--mca mpi_yield_when_idle 1 --mca btl ^openib --mca btl_tcp_if_include bond0 --mca plm_rsh_no_tree_spawn 1')
hostfile = '/home/heifeng.lwh/indexfs-0.3/script/nodes_client_hostfile'
mdtest = '/home/heifeng.lwh/indexfs-0.3/build/md_test/mdtest_nobk'
mpirun_path = '/home/heifeng.lwh/local/bin/'

if __name__ == "__main__":

    if len(sys.argv) <= 1:
        print('./script func')
        sys.stdout.flush()
        exit(0)
    
    if sys.argv[1] == 'restart_indexfs':
        restart_indexfs()
        exit(0)

    if sys.argv[1] == 'test_lat':
        restart_indexfs()
        prCyan('TEST_Servers_Clients:(%d,%d)' % (32, 1))

        structure = '-z 9 -b 3 -I 4'
        delay = 120

        phase_list = [
            # '-D -C -p %d' % delay,
            # '-D -T',
            # '-D -r',
            '-F -C -p %d' % delay,
            '-F -T',
            '-F -r'
        ]
        for phase in phase_list:
            # run_cmd('export FS_DENT_CACHE_SIZE=4194304; %s %s -d / %s' % (mdtest, structure, phase))
            run_cmd('export FS_DENT_CACHE_SIZE=8388608; %s %s -d / %s' % (mdtest, structure, phase))

        # /home/heifeng.lwh/indexfs-0.3/build/md_test/mdtest_nobk -z 9 -b 3 -I 4 -d /
    
    if sys.argv[1] == 'test_iops':
        restart_indexfs()
        prCyan('TEST_Servers_Clients:(%d,%d)' % (32, 1))

        structure = '-z 9 -b 3 -I 4'
        delay = 120

        # phase_list = [
        #     '-D -C -p %d' % delay,
        #     '-D -T',
        #     '-D -r',
        #     '-F -C -p %d' % delay,
        #     '-F -T',
        #     '-F -r'
        # ]
        # for phase in phase_list:
            # run_cmd('export FS_DENT_CACHE_SIZE=8388608; %smpirun -h %s -np %d %s %s %s -d / %s' % (mpirun_path, hostfile, 128, mpiargs, mdtest, structure, phase))

        run_cmd('export FS_DENT_CACHE_SIZE=8388608; %smpirun -hostfile %s -np %d %s %s %s -d /' % (mpirun_path, hostfile, 128, mpiargs, mdtest, structure))
